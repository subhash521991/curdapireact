import React, {useState, useEffect} from 'react'
//import {useHistory} from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';
import Wrapper from './Wrapper'

function ProductEdit(props) {

  const [title, setTitle] = useState('');
  const [image, setImage] = useState('');
  let navigate = useNavigate();
  const {id} = useParams();

  useEffect(()=>{
    fetch(`http://localhost:3004/products/${id}`)
    .then(res =>res.json())
    .then(product =>{
       setTitle(product.title);
       setImage(product.image);

       // eslint-disable-line
    })
  
  }, [id]) 

  const submit = (e)=>{
 
e.preventDefault();
fetch(`http://localhost:3004/products/${id}`, {

method: 'PUT',
headers: { 'Content-Type': 'application/json' },
body:JSON.stringify({title, image})

}).then(()=>{navigate('/admin/products');})

  }

  return (
    <Wrapper>
      <form onSubmit={submit}>

<label>Title</label>
<input type="text" name="title" defaultValue={title} onChange={e=>setTitle(e.target.value)} />
<label>Image</label>
<input type="text" name="image" defaultValue={image} onChange={e=>setImage(e.target.value)} />
<button type='submit'>Save</button>
      </form>

    </Wrapper>
  )
}


export default ProductEdit;